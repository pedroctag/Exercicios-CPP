#include <iostream>
#include <queue>

using namespace std;

int main(){

priority_queue<int> valores;

int s,v;
cout<<"---------------------------"<<endl<<"Programa de Heap STL"<<endl<<"---------------------------"<<endl<<endl;

while(s!=5){
cout<<"1.Insira um elemento na heap"<<endl<<"2.Remova um elemento da heap"<<endl<<"3.Tamanho da heap"<<endl<<"4.Primeiro elemento da heap"<<endl<<"5.Sair"<<endl<<endl;
cout<<"Escolha (1-5): "<<endl;
cin>>s;

switch(s){

case 1:
cout<<"Entre com o valor a ser inserido: "<<endl<<endl;
cin>>v;
valores.push(v);
break;

case 2:
cout<<"Elemento "<<valores.top()<<" removido da heap"<<endl<<endl;
valores.pop();
break;

case 3:
cout<<valores.size()<<endl;
break;

case 4:
cout<<"Primeiro elemento da heap (topo): "<<valores.top()<<endl<<endl;
break;

case 5:
return 0;
break;

default:
s=5;
return 0;
        }
    }
return 0;
}
